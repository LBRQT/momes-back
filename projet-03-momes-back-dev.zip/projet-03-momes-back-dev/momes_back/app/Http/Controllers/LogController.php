<?php

namespace App\Http\Controllers;

use App\Models\Log;
use DateTime;
use Illuminate\Http\Request;

class LogController extends Controller
{
    //
    public function createLog(
        string $name,
        string $detail,
        string $path,
    )
    {
        $newLog = new Log();

        $newLog->logName = $name;
        $newLog->logDetail = $detail;
        $newLog->logPath = $path;
        $newLog->logDate = new DateTime('now');

        $newLog->save();
        return true ;
    }
}
