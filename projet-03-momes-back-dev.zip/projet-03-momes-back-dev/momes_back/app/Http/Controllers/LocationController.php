<?php

namespace App\Http\Controllers;

use App\Http\Resources\LocationCollection;
use App\Http\Resources\LocationResource;
use App\Http\Controllers\LogController;
use App\Models\Equipment;
use App\Models\Location;
use App\Models\Type;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Laravel\Sanctum\PersonalAccessToken;
use PhpParser\Node\Stmt\TryCatch;

class LocationController extends Controller
{
    //
    public function index()
    {


        return new LocationResource(Location::all()->load(['types', 'equipment']));
        //
        // return new LocationCollection(Location::all());
    }

    public function show(string $id)
    {
        //
        return new LocationResource(Location::findOrFail($id)->load('types'));
    }

    public function store(Request $request, LogController $logController)
    {


        $validated = $request->validate([
            'locationName' => 'required|string|max:64',
            'adress' => 'required|string|max:180',
            'city' => 'required|string|max:180',
            'postalCode' => 'required|digits:5',
            'latitude' => 'required|numeric|between:-90,90',
            'longitude' => 'required|numeric|between:-180,180',
            'description' => 'required|string|max:500',
            'rating' => 'required|numeric|between:0,5',
            'types' => 'required|array',
            'equipments' => 'required|array'
        ]);

        if (count($validated['types']) <= 0) {
            return response()->json(['erreur' => 'Vous devez au moins choisir un type',]);
        }


        $foundTypes = [];

        foreach ($validated['types'] as $type) {
            $foundType = Type::find($type);
            if ($foundType != null) {
                $foundTypes[] = $foundType;
            }
        }

        $foundEquipments = [];

        foreach ($validated['equipments'] as $equipment) {
            $foundEquipment = Equipment::find($equipment);
            if ($foundEquipment != null) {
                $foundEquipments[] = $foundEquipment;
            }
        }


        $existingLocation = Location::where('locationName', $validated['locationName'])
            ->where('adress', $validated['adress'])
            ->where('city', $validated['city'])
            ->where('postalCode', $validated['postalCode'])
            ->first();

        if (!$existingLocation) {
            $location = new Location;

            $location->locationName = $validated['locationName'];
            $location->adress = $validated['adress'];
            $location->city = $validated['city'];
            $location->postalCode = $validated['postalCode'];
            $location->latitude = $validated['latitude'];
            $location->longitude = $validated['longitude'];
            $location->description = $validated['description'];
            $location->rating = $validated['rating'];
            $location->slug = Str::slug($validated['locationName']);
            $location->isApproved = false;

            try {
                $location->save();
                foreach ($foundTypes as $type) {
                    $location->types()->attach($type);
                };
                foreach ($foundEquipments as $equipment) {
                    $location->equipments()->attach($equipment);
                };
            } catch (\Throwable $th) {
                $errorMessage = $th->getMessage();
                $logController->createLog(
                    'error',
                    $errorMessage,
                    'LocationController::store'
                );
                return response()->json(['erreur' => "une erreur est survenu lors de l'enregistrement"], 403);
            }
            $token = PersonalAccessToken::findToken($request->bearerToken());
            $user = $token->tokenable;
            $logController->createLog(
                'success',
                'enregistrement du nouveau lieu : ' . $location->locationName . " par l'utilisateur " . $user->username . ', id : ' . $user->id,
                'LocationController::store'
            );
            return $location;
        } else {
            return response()->json(['message' => 'Le lieu est déjà enregistré. Veuillez vérifier les informations'], 403);
        }

        return "aagh";
    }
}
