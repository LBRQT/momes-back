<?php

namespace App\Http\Controllers;

use App\Http\Resources\UserCollection;
use App\Http\Resources\UserResource;
use App\Models\User;
use Illuminate\Hashing\HashManager;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use \Laravel\Sanctum\PersonalAccessToken;
use Illuminate\Support\Facades\Auth;

class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
        return new UserCollection(User::all());
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request, HashManager $hash, LogController $logController)
    {
        //


        $validated = $request->validate([
            'username' => 'required|string|max:180',
            'email' => 'required|email|max:180',
            'password' => 'required|string|max:255',
        ]);

        $errors = [];

        // On check is le nom d'utilisateur ne contient pas d'espace
        if (str_contains($validated['username'], ' ')) {
            $errors['usernameError'][] = "Le nom d'utilisateur ne doit pas contenir d'espace";
        };
        if (User::where('username', $validated['username'])->exists()) {
            $errors['usernameError'][] = "Ce nom d'utilisateur est déjà utilisé";
        };
        if (User::where('email', $validated['email'])->exists()) {
            $errors['emailError'][] = "Cette adresse email est déjà utilisée";
        };
        
        // Regex to verify if password contains beetween 8 and 20 characters, one lowercase, one uppercase and one number"
        $passwordRegex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{8,20}$^";
        if (!preg_match($passwordRegex, $validated['password'])) {
            $errors['passwordError'] = "Le mot de passe doit contenir entre 8 et 20 caractères avec au moins 1 minuscule, 1 majuscule et 1 chiffre";
        } 

        if (!empty($errors)) {
            return response()->json(['message' => 'Enregistrement impossible', 'errors' => $errors], 403);
        }

        $user = new User;
        $user->username = $validated['username'];
        $user->email = $validated['email'];
        $user->password = $hash->make($validated['password']);
        $user->accountStatus = 0;
        $user->slug = Str::slug($validated['username']);
        $user->role_id = 1;

        try {
            $user->save();
        } catch (\Throwable $th) {
            $errorMessage = $th->getMessage();
            $logController->createLog(
                'error',
                $errorMessage,
                'UserController::store'
            );
            return response()->json(['erreur' => "une erreur est survenu lors de l'enregistrement"], 403);
        };

        return $user;
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
        return new UserResource(User::findOrFail($id));
    }
    /**
     * Display the specified resource.
     */
    public function showUserByToken(Request $request)
    {
        $token = PersonalAccessToken::findToken($request->bearerToken());
        $user = $token->tokenable;
        return $user;
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $user = User::findOrFail($id);

        $validated = $request->validate([
            'username' => 'nullable|string|max:64',
            'email' => 'nullable|string|max:180',
            'numberOfChild' => 'nullable|integer|min:0',
            'slug' => 'nullable|string|max:64',
        ]);

        if($request->input('avatar'))
        {

            // $directory = 'images/profil';
            // $base64 = $decoded_data->image_name;
            // $image_parts = explode(";base64,", $base64);
            // $image_type_aux = explode("image/", $image_parts[0]); // $image_part[0] = extension
            // $image_type = $image_type_aux[1]; // extension
            // $image_base64 = base64_decode($image_parts[1]);
            // $file = $user->getUsername() . '.' . $image_type;
            // $uploadFile = file_put_contents($directory . '/'. $file, $image_base64);

        $base64Image = $request->input('avatar');
        $image_parts = explode(";base64,", $base64Image);
        $image_type_aux = explode("image/", $image_parts[0]); // $image_part[0] = extension
        $image_type = $image_type_aux[1]; // extension
        $image_base64 = base64_decode($image_parts[1]);
        $file = $user->username . '.' . $image_type;
        $filePath = storage_path('storage/images/' . $file);
        

        $user->avatar = file_put_contents($filePath, $image_base64);

        }

        try {
            $user->update($validated);
        } catch (\Throwable $th) {
            $errorMessage = $th->getMessage();
            switch ($errorMessage) {
                    //checking if error message contains duplicate and user_username_unique
                case preg_match('(Duplicate|users_username_unique)', $errorMessage) === 1:
                    return response()->json(['message' => "Le nom d'utilistaur n'est pas disponible"]);
                default:
                    return response()->json(['message' => $th->getMessage()]);
            }
        }

        return $user;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');

        if (auth()->attempt($credentials)) {
            // Authentification réussie, on commence par supprimer les anciens token 
            $user = Auth::user();
            PersonalAccessToken::where('tokenable_id', $user->id)->delete();
            // Génération d'un nouveau token
            $token = auth()->user()->createToken('auth-token')->plainTextToken;

            return response()->json(['token' => $token], 200);
        } else {
            return response()->json(['message' => 'Les informations d\'identification sont incorrectes.'], 401);
        }
    }
}
