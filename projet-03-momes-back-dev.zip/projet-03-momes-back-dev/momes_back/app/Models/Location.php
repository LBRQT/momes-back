<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Location extends Model
{
    use HasFactory;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'locationName',
        'adress',
        'city',
        'description',
        'postalCode',
        'latitude',
        'longitude',
        'rating',
        ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'isApproved'
    ];

    /**
     * *****************************************
     * Relations 
     * *****************************************
     */

     public function types(): BelongsToMany
     {
        return $this->belongsToMany(Type::class, 'location_type');
     }

     public function equipments(): BelongsToMany
     {
        return $this->belongsToMany(Equipment::class, 'location_equipment');
     }
}
