<?php

use App\Http\Controllers\LocationController;
use App\Http\Controllers\TypeController;
use App\Http\Controllers\UserController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::post('/login', [UserController::class, 'login'])->name('login');
Route::post('/users', [UserController::class, 'store']);


// Routes that need middleware auth:sacntum
Route::middleware('auth:sanctum')->group(function () {
    /**
     *   User
     */
    Route::get('/users', [UserController::class, 'index']);
    Route::get('/users/{id}', [UserController::class, 'show']);
    Route::get('/me', [UserController::class, 'showUserByToken']);
    Route::put('/users/{id}', [UserController::class, 'update']);
     /**
     *   Location
     */
    Route::get('/locations', [LocationController::class, 'index']);
    Route::get('/locations/{id}', [LocationController::class, 'show']);
    Route::post('/locations', [LocationController::class, 'store']);
     /**
     *   Types
     */
    Route::get('/types', [TypeController::class, 'index']);
    // Route::get('/types', [LocationController::class, 'show']);
    // Route::get('/types', [LocationController::class, 'create']);
    // Route::get('/types', [LocationController::class, 'update']);
    // Route::get('/types', [LocationController::class, 'delete']);
});
