<?php

namespace Tests\Unit;

use App\Models\User;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;

class ControllerTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_get_users(): void
    {
        $user = User::factory()->create();
        $token = $user->createToken('auth-token')->plainTextToken;
        Sanctum::actingAs($user, ['*']);


        $response = $this->withHeaders(['Authorization' => 'Bearer ' . $token,])->get('/api/users');

        $response->assertStatus(200);
    }

    public function test_get_one_user(): void
    {
        $user = User::factory()->create();
        $token = $user->createToken('auth-token')->plainTextToken;
        Sanctum::actingAs($user, ['*']);
        $response = $this->withHeaders(['Authorization' => 'Bearer ' . $token,])->get('/api/users/' . $user->id);

        $response->assertStatus(200);
    }
}
