<?php

namespace Tests\Unit;

use App\Models\Role;
use App\Models\User;
use Tests\TestCase;

class UsersTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_user_login(): void
    {
        $role = Role::factory()->create();
        $user = User::factory()->create();
        $user->role_id = $role->id;

        $response = $this->post('api/login', [
            'email' => $user->email,
            'password' => 'password',
        ]);

        $response->assertStatus(200);
    }

    public function test_user_register(): void
    {

        $username = "lalalalalaal";

        $response = $this->post('api/users', [
            'username' => $username,
            'email' => $username . '@gmail.com',
            'password' => 'Test123!!!',
        ]);


        $response->assertStatus(201);
    }

    public function test_user_roles(): void
    {
        $role = Role::factory()->create();
        $user = User::factory()->create();
        $user->role_id = $role->id;

        $this->assertEquals($role->id, $user->role_id);
    }
}
