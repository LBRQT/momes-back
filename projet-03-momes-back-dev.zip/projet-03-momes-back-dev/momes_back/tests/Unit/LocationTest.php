<?php

namespace Tests\Unit;

use App\Models\User;
use Laravel\Sanctum\Sanctum;
use Tests\TestCase;
use Illuminate\Support\Str;


class LocationTest extends TestCase
{
    /**
     * A basic unit test example.
     */
    public function test_register_location(): void
    {
        $user = User::factory()->create();
        $token = $user->createToken('auth-token')->plainTextToken;
        Sanctum::actingAs($user, ['*']);

        $locationName = fake()->name();

        $types = [
			"1",
			"2"
        ];
	    $equipments = [
            "1",
            "2"
        ];

        $response = $this->withHeaders(['Authorization' => 'Bearer ' . $token,])->post('/api/locations', [
            'locationName' => $locationName,
            'adress' => fake()->address(),
            'city' => fake()->city(),
            'postalCode' => fake()->randomNumber(5, true),
            'latitude' => fake()->latitude(),
            'longitude' => fake()->longitude(),
            'description' => fake()->text(500),
            'rating' => rand(0, 5),
            'isApproved' => fake()->boolean(),
            'slug' => Str::slug($locationName),
            'types' => $types,
            'equipments' => $equipments
    ]);

        $response->assertStatus(201);

    }
}
