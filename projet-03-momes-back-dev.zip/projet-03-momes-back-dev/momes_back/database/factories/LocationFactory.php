<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;


/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Location>
 */
class LocationFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $locationName = fake()->name();

        return [
            //
            'locationName' => $locationName,
            'adress' => fake()->address(),
            'city' => fake()->city(),
            'description' => fake()->text(500),
            'postalCode' => fake()->randomNumber(5, true),
            'latitude' => fake()->latitude(),
            'longitude' => fake()->longitude(),
            'rating' => rand(0, 5),
            'isApproved' => fake()->boolean(),
            'slug' => Str::slug($locationName),
        ];
    }
}
