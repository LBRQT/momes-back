<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;

use App\Models\Location;
use App\Models\Role;
use App\Models\Type;
use App\Models\Equipment;
use App\Models\User;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        $typesToSeed = [
            [
                "name" => "Restaurant"
            ],
            [
                "name" => "Hotel"
            ],
            [
                "name" => "Bar"
            ],
            [
                "name" => "Parc d'attraction"
            ],
        ];
        $equipmentToSeed = [
            [
                "name" => "Table à langer",
                "icon" => fake()->word()
            ],
            [
                "name" => "Chaises hautes",
                "icon" => fake()->word()

            ],
            [
                "name" => "Parc enfant",
                "icon" => fake()->word()
            ],
        ];
        Role::factory(2)->create();
        User::factory(10)->create();
        Location::factory(20)->create();
        
        
        foreach($typesToSeed as $type)
        {
            Type::factory()->create([
                'name' => $type['name'],
            ]);
        }
        foreach($equipmentToSeed as $equipment)
        {
            Equipment::factory()->create([
                'name' => $equipment['name'],
                'icon' => $equipment['icon']
            ]);
        }
        // \App\Models\User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);
    }
}
