# Mômes - Backend - API

## Installation
First of all you can clone the repo.  
Copy `.env.example` and rename the copy as `.env`. Complete this file.

## Running localy without docker
You should create a database with your local database management system, like mysql. You can call the database momes or any other name. Juste make sure you have the correct name in your .env.

Go back to your repo and switch to the dev branch and do `composer install command`.
Then you can enter `php artisan serve` to run the app. 
If you need to populate your database you can do `php artisan migrate --seed`.

## Running with Docker
### Without VM
For running application localy, without passing through the Virtual Machine, make sure you have not mysql or servor like apache running.

You can do `sudo service mysql stop` and `sudo systemctl stop apache2` to stop them for exemple. 
Then just execute `./vendor/bin/sail up`. 

In another terminal you can do `vendor/bin/sail artisan migrate --seed` to launch migration and seeder.

### With VM
After the installation step you can follow those instructions : https://kourou.oclock.io/ressources/recap-quotidien/meduse-e13-sail-orm-eloquent-migrations-seeders/

You can skip the step where you have to create the .env, at this point it should have already been created.

At point 6, you can do `./vendor/bin/sail up`.
